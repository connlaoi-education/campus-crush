<!-- Page Info -->
<?php
    $title = "Campus Crush - Register";
    $createddate = "September 19 2017";
    $updateddate = "xxxx xx 2017";
    $filename = "user-register.php";
    $banner = "Campus Crush - Registration";
    $description = "Sign up quickly and easily - start meeting new people now!";
?>
<!--
  Creator:      Jeremy Power, Minh Tri Ly
  Filename:    <?php echo $filename; ?>
  Created:      <?php echo $createddate; ?>
  Updated:     <?php echo $updateddate; ?>
  Description: <?php echo $description; ?>
-->

<!-- Include Header PHP -->
<?php include 'header.php'; ?>

<?php include 'footer.php'; ?>